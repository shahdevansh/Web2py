Create one large html page which when opened in browser display same contents as shown in various screen-shots included in this assignment. Note that things may appear little different based on browser version, screen resolution, toolbars installed in browser etc. Hence minor differences in output are ok, major things like formatting(bold, italic, underline), alignment(left, right, justified), color(red,yellow), etc. should match. 

Note: 1. Indent your code properly. 
      2. You should not use deprecated tags for achieving the results. 
      3. You have to upload both the HTML file and the eiffel tower image as a tar file as part of the assignment.
